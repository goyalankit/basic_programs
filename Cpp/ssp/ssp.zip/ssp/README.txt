Note: All the executables have been created using ICPC compiler.

I have included cpp files and their executables.

To compile using g++:
g++ -o dijkstra dijkstra.cpp

pass TRUE to PRINT TO A FILE as a third/last parameter

Usage: ./dijkstra sourceNode true


similarly other programs can be run
